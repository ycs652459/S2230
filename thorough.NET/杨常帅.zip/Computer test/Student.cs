﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Computer_test
{
    class Student
    {
        public string StuName;//学生姓名
    }
}
